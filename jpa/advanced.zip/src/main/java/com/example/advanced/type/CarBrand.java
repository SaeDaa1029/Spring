package com.example.advanced.type;

public enum CarBrand {
    LAMBORGHINI, BENTLEY, FERRARI, PORSCHE, BUGATTI, MCLAREN, ASTON_MARTIN, KIA
}
