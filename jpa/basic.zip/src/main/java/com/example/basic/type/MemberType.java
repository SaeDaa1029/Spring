package com.example.basic.type;

public enum MemberType {

    MEMBER, ADMIN

}
